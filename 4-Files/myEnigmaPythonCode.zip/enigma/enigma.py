#!/usr/bin/env python
# -*- coding: utf-8 -*-

"""
        ROTORS
INPUT           ABCDEFGHIJKLMNOPQRSTUVWXYZ
Rotor I         EKMFLGDQVZNTOWYHXUSPAIBRCJ
Rotor II        AJDKSIRUXBLHWTMCQGZNPYFVOE
Rotor III       BDFHJLCPRTXVZNYEIWGAKMUSQO
Rotor IV        ESOVPZJAYQUIRHXLNFTGKDCMWB
Rotor V         VZBRGITYUPSDNHLXAWMJQOFECK
Rotor VI        JPGVOUMFYQBENHZRDKASXLICTW
Rotor VII       NZJHGRCXMYSWBOUFAIVLPEKQDT
Rotor VIII      FKQHTLXOCBJSPDZRAMEWNIUYGV
Beta rotor      LEYJVCNIXWPBQMDRTAKZGFUHOS
Gamma rotor     FSOKANUERHMBTIYCWLQPZXVGJD

        REFLECTORS
reflector B         (AY) (BR) (CU) (DH) (EQ) (FS) (GL) (IP) (JX) (KN) (MO) (TZ) (VW)
reflector C         (AF) (BV) (CP) (DJ) (EI) (GO) (HY) (KR) (LZ) (MX) (NW) (TQ) (SU)
reflector B Dünn    (AE) (BN) (CK) (DQ) (FU) (GY) (HW) (IJ) (LO) (MP) (RX) (SZ) (TV)
reflector C Dünn    (AR) (BD) (CO) (EJ) (FN) (GT) (HK) (IV) (LM) (PW) (QZ) (SX) (UY)

        STEPPING
Rotor I     at R
Rotor II    at F
Rotor III   at W
Rotor IV    at K
Rotor V     at A
Rotors VI, VII and VIII at A and at N

        PLUG BOARD
10 pairs of letters can be swapped

        ROUTE
Keyboard, PlugBoard, Rotor 3(R), Rotor 2(R), Rotor 1(R), Reflector, Rotor 1, Rotor 2, Rotor 3, PlugBoard(R), LampBoard


Day|Ref|Wheels     |Ring|Ground|Plugs
 1   B  II I IV    |EOE | IYR  |EX FB HP LJ MS QT RO UG YC ZI
 2   C  VII I VI   |ARV | JPM  |IB JP KO NW QE RM US XD YA ZG
 3   B  IV II VI   |LXK | VMX  |BC EM IF LS OY QA UP VK WJ ZH
 4   B  IV V VIII  |WLI | RYF  |BR DQ EK HC LY MF SU TO VJ XW
 5   C  II IV VIII |ZUH | RSN  |CZ GY HN JB LS OK QR UM VI WP
 6   C  III VIII V |ISX | ALK  |AX DR GU HB IP JO NC QY VT ZF
 7   C  II V IV    |MEI | MPS  |IK JH MD NO QR SP TG UF XA ZL
 8   B  IV VI VII  |ZVD | LKW  |BA CQ EH GF KS MI NV UT WY ZD
 9   B  V VII III  |OQO | ABK  |CN HI JR KT PW QO UV XF YD ZL
 10  B  III VII V  |WMF | XNQ  |AX CE DV HM KQ OW RL SI TG ZF


"""
import sys
import unittest

ALPHA             =  "ABCDEFGHIJKLMNOPQRSTUVWXYZ"
Rotor_Perm = { 'I':    "EKMFLGDQVZNTOWYHXUSPAIBRCJ",
               'II':   "AJDKSIRUXBLHWTMCQGZNPYFVOE",
               'III':  "BDFHJLCPRTXVZNYEIWGAKMUSQO",
               'IV':   "ESOVPZJAYQUIRHXLNFTGKDCMWB",
               'V':    "VZBRGITYUPSDNHLXAWMJQOFECK",
               'VI':   "JPGVOUMFYQBENHZRDKASXLICTW",
               'VII':  "NZJHGRCXMYSWBOUFAIVLPEKQDT",
               'VIII': "FKQHTLXOCBJSPDZRAMEWNIUYGV"
             }

Rotor_Notch = { 'I': 'R', 'II': 'F',  'III': 'W',  'IV': 'K',
                'V': 'A', 'VI': 'AN', 'VII': 'AN', 'VIII': 'AN'
              }

Beta_rotor  = "LEYJVCNIXWPBQMDRTAKZGFUHOS"
Gamma_rotor = "FSOKANUERHMBTIYCWLQPZXVGJD"

Reflector_B      = "YRUHQSLDPXNGOKMIEBFZCWVJAT"
Reflector_C      = "FVPJIAOYEDRZXWGCTKUQSBNMHL"
Reflector_B_Dunn = "ENKQAUYWJICOPBLMDXZVFTHRGS"
Reflector_C_Dunn = "RDOBJNTKVEHMLFCWZAXGYIPSUQ"



class InvalidPlugError(Exception):
    def __init__(self, value):
        self.value = value
    def __str__(self):
        return repr(self.value)
        
class PlugBoardFullError(Exception):
    def __init__(self, value):
        self.value = value
    def __str__(self):
        return repr(self.value)
        
class Alphabet:
    def __init__(self):
        self.alpha = ALPHA #"ABCDEFGHIJKLMNOPQRSTUVWXYZ"
    def pos(self,l):
        return self.alpha.index(l)
    def normal(self,i):
        if i<0: return (26+i) # i is negative
        if i>=26: return (i-26)
        return i
    def letter(self,i):
        return self.alpha[i]
alpha = Alphabet()


class PlugBoard:
    """A Plugboard - up to 10 pairs of letters can be transposed."""
    def __init__(self):
        self.board = []
        for letter in ALPHA:
            self.board.append(letter)

        self.plugs=[]
        self.plugCount=0
        self.maxPlugs=10

    def _connect(self,A,B):
        posA=self.board.index(A)
        posB=self.board.index(B)
        # apply the plug
        self.board[posA]=B
        self.board[posB]=A
        # remember the use of the plug
        self.plugs.append(A)
        self.plugs.append(B)
        self.plugCount+=1

    def addPlug(self,plug):
        A = plug[0]
        B = plug[1]
        if (A == B):
            raise InvalidPlugError((A,B))
        if (A in self.plugs or B in self.plugs):
            raise InvalidPlugError((A,B))
        if self.plugCount == self.maxPlugs:
            raise PlugBoardFullError(self.maxPlugs)
        
        self._connect(A, B)

    def encrypt(self,ltr):
        """encrypt a letter"""
        #print "PlugBoard in",ltr,"out",self.board[lpos(ltr)]
        return self.board[alpha.pos(ltr)]

    def __repr__(self):
        """print a plugboard"""
        return "Board="+repr(self.board)+"\nPlugs="+repr(self.plugs)


class RotorWheel:
    """A Rotor Wheel"""
    def __init__(self, id, loc, r_setting, offset, debug=False):
        """"""
        self.rotor = Rotor_Perm[id]
        self.notch = Rotor_Notch[id]
        self.location = loc
        self.ring_offset = alpha.pos(r_setting) #-1
        self.default_ring_offset = self.ring_offset
        self.rotation = alpha.pos(offset)
        self.default_rotation = self.rotation
        self.name = id
        self.debug = debug
        self.offset = self.ring_offset - self.rotation
        self.default_offset = self.offset
        
    def __repr__(self):
        """print the rotor wheel"""
        ret = "rotor %s = %s" % (self.name,self.rotor)
        ret += " " + self.location
        ret += " ring_setting = %d" % (self.ring_offset + 1)
        ret += " rotation = %d" % self.rotation
        return ret

    def reset(self):
        """reset the position of the rotor wheel"""
        self.offset = self.default_offset
        self.rotation = self.default_rotation
        
    def rotate(self):
        """"""
        self.rotation +=1
        if self.rotation>=26: self.rotation = self.rotation-26
        self.offset = self.ring_offset - self.rotation
        
    def inNotchPosition(self):
        #print "inNotchPosition",self.rotation, alpha.pos(self.notch)
        return self.rotation+1 == alpha.pos(self.notch[0]) or (len(self.notch)==2 and self.rotation+1 == alpha.pos(self.notch[1]))
        
    def encrypt(self,letter,dir):
        """This should be split into offset_in, encrypt (forward and reverse) and offset_out"""
        #if self.debug: print "offset",self.offset
        
        #if self.debug: print "1",letter,"[alpha.pos(",letter,")",alpha.pos(letter),"-offset=",
        offset=alpha.pos(letter) - self.offset
        #if self.debug: print offset,
        #try:
        #    if self.debug: print alpha.letter(offset),
        #except IndexError:
        #    pass
        #if self.debug: print "alpha.normal(",offset,")",
        norm=alpha.normal(offset)
        #if self.debug: print norm,"alpha.letter(",norm,")",alpha.letter(norm)
        out = alpha.letter(alpha.normal(alpha.pos(letter) - self.offset)) 

        if dir == 'F':
            #if self.debug: print out,"encrypted is",self.rotor[alpha.pos(out)]
            out = self.rotor[alpha.pos(out)]
        if dir == 'R':
            #if self.debug: print out,"encrypted is",alpha.letter(self.rotor.index(out))
            out = alpha.letter(self.rotor.index(out))
            
        #if self.debug: print "2",out,"[alpha.pos(",out,")",alpha.pos(out),"+offset=",
        offset=alpha.pos(out) + self.offset
        #if self.debug: print offset,
        #try:
        #    if self.debug: print alpha.letter(offset),
        #except IndexError:
        #    pass
        #if self.debug: print "alpha.normal(offset)",
        norm=alpha.normal(offset)
        #if self.debug: print norm,"alpha.letter(",norm,")",alpha.letter(norm)
        out = alpha.letter(alpha.normal(alpha.pos(out) + self.offset))
        return out
        
    
class Keyboard:
    """The Keyboard - When a key is pressed the pawls push any rotor wheels they are engaged with. 
    Pawl 1 is only resting against the ratchet of the left rotor.
    Pawl 2 is resting against the notch of the right rotor and the ratchet of the middle rotor.
    Pawl 3 is resting against the notch of the middle rotor and the rathcet of the left rotor.
    """
    def __init__(self, L,M,R):
        self.rotorL = L
        self.rotorM = M
        self.rotorR = R
        
    def rotateWheels(self):
        """Always rotate the right rotor. Check whether middle or left rotors should also rotate."""
        rotateM = rotateL = False
        if self.rotorR.inNotchPosition(): #rotate middle and right rotors
            rotateM=True 
        if self.rotorM.inNotchPosition(): #rotate left and middle rotors
            rotateL=True 
            rotateM=True
        self.rotorR.rotate()
        if rotateM: 
            self.rotorM.rotate()
        if rotateL: 
            self.rotorL.rotate()
            
    def press(self,letter):
        self.rotateWheels()

        
class EnigmaMachine:
    """The Enigma Machine - it needs three rotors, a reflector and a plugboard"""
    def __init__(self, (rotor1, rotor2, rotor3), reflector, plugboard):
        self.rotor = {'Left':rotor1, 'Middle':rotor2, 'Right':rotor3}
        self.reflector = reflector
        self.plugboard = plugboard
        self.keyboard = Keyboard(rotor1, rotor2, rotor3)
        self.debug = False

    def reset(self): #, (rotor1, rotor2, rotor3)):
        for location in ['Left', 'Middle', 'Right']:
            self.rotor[location].reset()
        
    def encrypt_message(self,message,debug=False):
        answer=''
        for msgltr in message:
            #print "msgltr",msgltr
            if msgltr != ' ':
                encltr = msgltr
                self.keyboard.press(encltr)
                encltr = self.plugboard.encrypt(encltr)
                #print encltr
                for location in ['Right', 'Middle', 'Left']:
                    encltr=self.rotor[location].encrypt(encltr,'F')
                #print encltr
                encltr=self.reflector[alpha.pos(encltr)]
                #print encltr
                for location in ['Left', 'Middle', 'Right']:
                    encltr=self.rotor[location].encrypt(encltr,'R')
                #print encltr
                encltr = self.plugboard.encrypt(encltr)
                #print encltr
                answer += encltr
        return answer
        
        
def createPlugBoard(plugs):
    PB = PlugBoard()
    for plug in plugs:
        PB.addPlug(plug)
    return PB


def Enigma_Test_1():
    print "\n-- Enigma Test 1 --"
    Enigma = EnigmaMachine (  (RotorWheel('I',   'Left',  'A','A'),
                               RotorWheel('II',  'Middle','A','A'),
                               RotorWheel('III', 'Right', 'A','A')),
                               Reflector_B,
                               createPlugBoard([]) )
    clue="AAAAA"
    print clue
    answer = Enigma.encrypt_message(clue,False)
    print answer
    assert answer == "BDZGO"
    
def Enigma_Test_2():
    print "\n-- Enigma Test 2 --"
    Enigma = EnigmaMachine (  (RotorWheel('I',   'Left',  'A','A'),
                               RotorWheel('II',  'Middle','A','A'),
                               RotorWheel('III', 'Right', 'A','A')),
                               Reflector_B,
                               createPlugBoard([]) )
    clue="OPGN DXCF WEVT NRSD ULTP" 
    print clue
    answer = Enigma.encrypt_message(clue,False)
    print answer
    assert answer == "THISISASECRETMESSAGE"
    # THIS IS A SECRET MESSAGE

def Enigma_Test_3():
    print "\n-- Enigma Test 3 --"
    Enigma = EnigmaMachine (  (RotorWheel('VII', 'Left',  'A','A'),
                               RotorWheel('I',   'Middle','A','A'),
                               RotorWheel('III', 'Right', 'A','A')),
                               Reflector_C,
                               createPlugBoard([]) )
    clue="ZUZB PCBG EOGY TRPB VUXG QTIX AWHT ZDZV ITOA "
    print clue
    answer = Enigma.encrypt_message(clue,False)
    print answer
    assert answer == "ENIGMAWASUSEDDURINGTHESECONDWORLDWAR"
    # ENIGMA WAS USED DURING THE SECOND WORLD WAR

def Enigma_Test_4():
    print "\n-- Enigma Test 4 --"
    # Rotor 5 6 1 , Rings G G P, reflector B, plugs E-O F-P L-Y 
    Enigma = EnigmaMachine (  (RotorWheel('V',   'Left',  'G','A'),
                               RotorWheel('VI',  'Middle','G','A'),
                               RotorWheel('I',   'Right', 'P','A')),
                               Reflector_B,
                               createPlugBoard(['EO','FP','LY']) )
    clue="WGLS CWYJ NLAY YMPW KSPP IKBK QDUA JVKO BLSS HIBO MHWO"
    print clue
    answer = Enigma.encrypt_message(clue,False)
    print answer
    assert answer == "DERFUEHRERISTTOTXDERKAMPFGEHTWEITERXDOENITZX"
    #DER FUEHRER IST TOT X DER KAMPF GEHT WEITER X DOENITZ X
    
"""
    Answers

    1. BDZGO

    2. THIS IS A SECRET MESSAGE

    3. ENIGMA WAS USED DURING THE SECOND WORLD WAR

    4. In German: Der Führer ist tot. Der Kampf geht weiter. Dönitz
    Or, translated into English: The Führer is dead. The battle will continue. Dönitz
"""
    
########################
# MAIN STARTS HERE
########################


if __name__ == '__main__':

    Enigma_Test_1()
    Enigma_Test_2()
    Enigma_Test_3()
    Enigma_Test_4()
