#!/usr/bin/env python


import unittest
from enigma import *

class EnigmaTest(unittest.TestCase):

    def testRotorI_P_A_W(self):
        RW = RotorWheel('I',"Right",'P','A') # 16,0
        RW.rotate()
        #print "Rotor I - for - W should become J",RW.encrypt("W",'F')
        self.assertEqual("J",RW.encrypt("W",'F'))
        
    def testRotorI_P_A_V(self):
        RW = RotorWheel('I',"Right",'P','A') # 16,0
        RW.rotate()
        #print "Rotor I - rev - V should become D",RW.encrypt("V",'R'),"\n"
        self.assertEqual("D",RW.encrypt("V",'R'))
    
    def testRotorVI_G_A_J(self):
        RW = RotorWheel('VI',"Middle",'G','A') # 7,0
        #print "Rotor VI - for - J should become B",RW.encrypt("J",'F')
        self.assertEqual("B",RW.encrypt("J",'F'))
        
    def testRotorVI_G_A_X(self):
        RW = RotorWheel('VI',"Middle",'G','A') # 7,0
        #print "Rotor VI - rev - X should become V",RW.encrypt("X",'R'),"\n"
        self.assertEqual("V",RW.encrypt("X",'R'))
    
    def testRotorV_G_A_V(self):
        RW = RotorWheel('V',"Left",'G','A') # 7,0
        #RW.printSettings()
        #print "Rotor V - for - B should become U",RW.encrypt("B",'F')
        self.assertEqual("U",RW.encrypt("B",'F'))
        
    def testRotorV_G_A_C(self):
        RW = RotorWheel('V',"Left",'G','A') # 7,0
        #RW.printSettings()
        #print "Rotor V - rev - C should become X",RW.encrypt("C",'R'),"\n"
        self.assertEqual("X",RW.encrypt("C",'R'))


    def testRotorRotation(self):
        #print "Testing Rotor Rotation roll-over"
        RW = RotorWheel('I','Right','A','A')
        for x in range(0,26):
            self.assertEqual(RW.rotation,x)
            self.assertEqual(RW.offset,x*-1) 
            RW.rotate()
        for x in range(26,30):
            self.assertEqual(RW.rotation,x-26)
            self.assertEqual(RW.offset,(x-26)*-1) 
            RW.rotate()
    
    def testRotorWheel_Print(self):
        RW = RotorWheel('I','Right','A','A')
        ret = "%s" % RW
        self.assertEqual(ret,'rotor I = EKMFLGDQVZNTOWYHXUSPAIBRCJ Right ring_setting = 1 rotation = 0')
        
    def testRotorWheel_Reset(self):
        RW = RotorWheel('I','Right','A','A')
        RW.rotate()
        self.assertEqual(RW.rotation,1)
        self.assertEqual(RW.offset,-1)
        RW.reset()
        self.assertEqual(RW.rotation,0)
        self.assertEqual(RW.offset,0)
        
    def testKeyboard(self):
        #print "Testing Keyboard"
        KB = Keyboard(RotorWheel('I','Left','A','A'),RotorWheel('II','Middle','A','A'),RotorWheel('III','Right','A','A'))
        for x in range(102):#(752):
            KB.press('A')
            #print KB.rotorL.rotation, KB.rotorM.rotation,KB.rotorR.rotation
            if x == 21:
                self.assertEqual(0, KB.rotorL.rotation)
                self.assertEqual(1, KB.rotorM.rotation)
                self.assertEqual(22,KB.rotorR.rotation)
            if x == 99:
                self.assertEqual(0, KB.rotorL.rotation)
                self.assertEqual(4, KB.rotorM.rotation)
                self.assertEqual(22,KB.rotorR.rotation)
            if x == 100:
                self.assertEqual(1, KB.rotorL.rotation)
                self.assertEqual(5, KB.rotorM.rotation)
                self.assertEqual(23,KB.rotorR.rotation)

    def testPlugBoard_InvalidPlugError_1(self):
        """"""
        PB=PlugBoard()
        PB.addPlug('AB')
        with self.assertRaises(InvalidPlugError) as e:
            PB.addPlug('AB')
        exc = e.exception
        self.assertEqual("%s" % exc,"('A', 'B')")

    def testPlugBoard_InvalidPlugError_2(self):
        """"""
        PB=PlugBoard()
        PB.addPlug('AB')
        with self.assertRaises(InvalidPlugError):
            PB.addPlug('BA') 

    def testPlugBoard_InvalidPlugError_3(self):
        """"""
        PB=PlugBoard()
        PB.addPlug('AB')
        with self.assertRaises(InvalidPlugError):
            PB.addPlug('AC')

    def testPlugBoard_InvalidPlugError_4(self):
        """"""
        PB=PlugBoard()
        PB.addPlug('AB')
        with self.assertRaises(InvalidPlugError):
            PB.addPlug('AA')

    def testPlugBoard_PlugBoardFullError(self):
        """"""
        PB=PlugBoard()
        PB = createPlugBoard(['AB', 'IJ', 'MN', 'TZ', 'QO', 'CP', 'DY', 'EX', 'FW', 'GV'])
        with self.assertRaises(PlugBoardFullError) as e:
            PB.addPlug(('K','S'))
        exc = e.exception
        self.assertEqual("%s" % exc,"10")

    def testPlugBoard_Print(self):
        PB=PlugBoard()
        PB = createPlugBoard(['AB', 'IJ'])
        ret = "%s" % PB
        self.assertEqual(ret,"Board=['B', 'A', 'C', 'D', 'E', 'F', 'G', 'H', 'J', 'I', 'K', 'L', 'M', 'N', 'O', 'P', 'Q', 'R', 'S', 'T', 'U', 'V', 'W', 'X', 'Y', 'Z']\nPlugs=['A', 'B', 'I', 'J']")
        
    def testPlugBoard_encrypt(self):
        PB=PlugBoard()
        PB = createPlugBoard(['AB', 'IJ', 'MN', 'TZ', 'QO', 'CP', 'DY', 'EX', 'FW', 'GV'])
        self.assertEqual(PB.encrypt('C'),'P')
        self.assertEqual(PB.encrypt('P'),'C')
        self.assertEqual(PB.encrypt('D'),'Y')
        self.assertEqual(PB.encrypt('U'),'U')
    
    def testEnigmaMachine_Encrypt(self):
        #print "\n-- Enigma Test 4 --"
        # Rotor 5 6 1 , Rings G G P, reflector B, plugs E-O F-P L-Y 
        Enigma = EnigmaMachine (  (RotorWheel('V',   'Left',  'G','A'),
                                   RotorWheel('VI',  'Middle','G','A'),
                                   RotorWheel('I',   'Right', 'P','A')),
                                   Reflector_B,
                                   createPlugBoard(['EO','FP','LY']) )
        clue="WGLS CWYJ NLAY YMPW KSPP IKBK QDUA JVKO BLSS HIBO MHWO"
        #print clue
        self.assertEqual(Enigma.encrypt_message(clue,False),
                         "DERFUEHRERISTTOTXDERKAMPFGEHTWEITERXDOENITZX")
        
    def testEnigmaMachine_Reset(self):
        #print "\n-- Enigma Test 4 --"
        # Rotor 5 6 1 , Rings G G P, reflector B, plugs E-O F-P L-Y 
        Enigma = EnigmaMachine (  (RotorWheel('V',   'Left',  'G','A'),
                                   RotorWheel('VI',  'Middle','G','A'),
                                   RotorWheel('I',   'Right', 'P','A')),
                                   Reflector_B,
                                   createPlugBoard(['EO','FP','LY']) )
        clue="WGLS CWYJ NLAY YMPW KSPP IKBK QDUA JVKO BLSS HIBO MHWO"
        #print clue
        self.assertEqual(Enigma.encrypt_message(clue,False),
                         "DERFUEHRERISTTOTXDERKAMPFGEHTWEITERXDOENITZX")
        Enigma.reset()
        self.assertEqual(Enigma.encrypt_message(clue,False),
                         "DERFUEHRERISTTOTXDERKAMPFGEHTWEITERXDOENITZX")
        

if __name__ == '__main__':
    
    print "\nUnit Tests for Enigma Machine"
    unittest.main()
    

